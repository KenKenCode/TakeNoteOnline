# About .github

This directory handles special features to be used on simple-keyboard's Github repository.
It is not needed for simple-keyboard to run and can be safely removed.