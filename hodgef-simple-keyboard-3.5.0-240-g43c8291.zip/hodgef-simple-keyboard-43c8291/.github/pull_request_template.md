## Description

A few sentences describing the overall goals of the pull request's commits.

## Checks

- [ ] Tests ( `npm run test -- --coverage` ) Coverage at `./coverage/lcov-report/index.html` should be 100%
